document.addEventListener('DOMContentLoaded', () => {
    // Constants and Variables
    const abilityScores = ['Strength', 'Dexterity', 'Constitution', 'Intelligence', 'Wisdom', 'Charisma'];
    const skills = [
        'Acrobatics', 'Animal Handling', 'Arcana', 'Athletics', 'Deception',
        'History', 'Insight', 'Intimidation', 'Investigation', 'Medicine',
        'Nature', 'Perception', 'Performance', 'Persuasion', 'Religion',
        'Sleight of Hand', 'Stealth', 'Survival'
    ];
    const racialBonuses = {
        'Dwarf': { constitution: 2 },
        'Elf': { dexterity: 2 },
        'Halfling': { dexterity: 2 },
        'Human': { strength: 1, dexterity: 1, constitution: 1, intelligence: 1, wisdom: 1, charisma: 1 },
        'Dragonborn': { strength: 2, charisma: 1 },
        'Gnome': { intelligence: 2 },
        'Half-Elf': { charisma: 2 },
        'Half-Orc': { strength: 2, constitution: 1 },
        'Tiefling': { intelligence: 1, charisma: 2 }
    };

    // DOM Elements
    const startMenu = document.getElementById('startMenu');
    const characterCreator = document.getElementById('characterCreator');
    const cards = Array.from(document.querySelectorAll('#characterCreator .card'));
    const saveCharacterButton = document.getElementById('saveCharacterButton');
    const randomNameButton = document.getElementById('randomName');
    const raceSelect = document.getElementById('race');
    const abilityColumns = document.querySelectorAll('.ability-column');
    const skillList = document.getElementById('skillList');
    const characterForm = document.getElementById('characterForm');
    const themeControls = document.querySelector('.theme-controls');

    let currentCardIndex = -1; // Start at -1 to represent the start menu

    // Navigation Functions
    function showCard(index) {
        console.log('Showing card:', index);
        if (index === -1) {
            startMenu.classList.remove('hidden');
            characterCreator.classList.add('hidden');
            themeControls.classList.add('hidden');
        } else {
            startMenu.classList.add('hidden');
            characterCreator.classList.remove('hidden');
            themeControls.classList.add('hidden');
            cards.forEach((card, i) => {
                card.classList.toggle('hidden', i !== index);
            });
        }

        currentCardIndex = index;
    }

    function updateNavigationButtons(index) {
        cards.forEach((card, i) => {
            const prevButton = card.querySelector('.prev-button');
            const nextButton = card.querySelector('.next-button');
            
            if (prevButton) {
                prevButton.classList.toggle('hidden', i === 0);
                prevButton.onclick = (e) => {
                    e.preventDefault();
                    showCard(i - 1);
                };
            }
            if (nextButton) {
                nextButton.classList.toggle('hidden', i === cards.length - 1);
                nextButton.onclick = (e) => {
                    e.preventDefault();
                    showCard(i + 1);
                };
            }
        });
    }

    // Initialize navigation
    function setupNavigation() {
        console.log('Setting up navigation');
        document.querySelectorAll('.next-button, .prev-button').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('Navigation button clicked');
                if (this.classList.contains('next-button')) {
                    showCard(currentCardIndex + 1);
                } else {
                    showCard(currentCardIndex - 1);
                }
            });
        });

        const startButton = startMenu.querySelector('.next-button');
        if (startButton) {
            startButton.addEventListener('click', function(e) {
                e.preventDefault();
                console.log('Start button clicked');
                showCard(0);
            });
        }
    }

    // Ability Scores Functions
    function createAbilityScoreElements() {
        abilityScores.forEach((ability, index) => {
            const abilityDiv = document.createElement('div');
            abilityDiv.classList.add('ability-score');
            abilityDiv.innerHTML = `
                <button type="button" class="rollAbility" data-ability="${ability.toLowerCase()}">
                    ${ability}
                </button>
                <div class="roll-options hidden"></div>
            `;
            abilityColumns[Math.floor(index / 3)].appendChild(abilityDiv);
        });
    }

    function getModifierString(score) {
        const modifierTable = {
            1: -5, 2: -4, 3: -4, 4: -3, 5: -3, 6: -2, 7: -2, 8: -1, 9: -1,
            10: 0, 11: 0, 12: 1, 13: 1, 14: 2, 15: 2, 16: 3, 17: 3, 18: 4,
            19: 4, 20: 5, 21: 5, 22: 6, 23: 6, 24: 7, 25: 7, 26: 8, 27: 8,
            28: 9, 29: 9, 30: 10
        };
        return modifierTable[score] || 0;
    }

    function handleRollAbility(button) {
        const ability = button.dataset.ability;
        const rollOptionsDiv = button.nextElementSibling;
        rollOptionsDiv.innerHTML = '';
        rollOptionsDiv.classList.remove('hidden');

        for (let i = 0; i < 3; i++) {
            const roll = rollAbilityScore();
            const rollButton = document.createElement('button');
            rollButton.classList.add('roll-option');
            const modifier = getModifierString(roll);
            rollButton.textContent = `${roll} (${modifier >= 0 ? '+' : ''}${modifier})`;
            rollButton.dataset.roll = roll;
            rollButton.dataset.modifier = modifier;
            rollOptionsDiv.appendChild(rollButton);
        }
    }

    function handleRollOption(button) {
        const abilityScore = button.closest('.ability-score');
        const abilityButton = abilityScore.querySelector('.rollAbility');
        const ability = abilityButton.dataset.ability;
        const roll = button.dataset.roll;
        const modifier = button.dataset.modifier;
        
        abilityButton.textContent = `${ability}: ${roll} ${modifier >= 0 ? '+' : ''}${modifier}`;
        abilityButton.dataset.value = roll;
        abilityButton.disabled = true;
        
        // Remove the roll options completely
        const rollOptionsDiv = abilityScore.querySelector('.roll-options');
        if (rollOptionsDiv) {
            rollOptionsDiv.remove();
        }
        
        updateAbilityModifier(ability);
    }

    function updateAbilityModifier(ability) {
        const button = document.querySelector(`[data-ability="${ability}"]`);
        if (button) {
            const baseScore = parseInt(button.dataset.value) || 0;
            const racialBonus = getRacialBonus(ability);
            const totalScore = baseScore + racialBonus;
            const modifier = getModifierString(totalScore);
            button.textContent = `${ability}: ${totalScore} ${modifier >= 0 ? '+' : ''}${modifier}`;
            button.title = `Base: ${baseScore}, Racial Bonus: ${racialBonus}, Total: ${totalScore}`;
        }
    }

    function rollAbilityScore() {
        const rolls = Array(4).fill().map(() => Math.floor(Math.random() * 6) + 1);
        return rolls.sort((a, b) => b - a).slice(0, 3).reduce((sum, roll) => sum + roll, 0);
    }

    function getRacialBonus(ability) {
        const race = raceSelect.value;
        return (racialBonuses[race] && racialBonuses[race][ability.toLowerCase()]) || 0;
    }

    function updateAbilityScores() {
        abilityScores.forEach(ability => updateAbilityModifier(ability.toLowerCase()));
    }

    // Event Listeners for Ability Scores
    document.body.addEventListener('click', (e) => {
        if (e.target.classList.contains('rollAbility') && !e.target.disabled) {
            e.preventDefault();
            handleRollAbility(e.target);
        } else if (e.target.classList.contains('roll-option')) {
            e.preventDefault();
            handleRollOption(e.target);
        }
    });

    // Racial Bonuses
    raceSelect.addEventListener('change', (e) => {
        const selectedRace = e.target.value;
        const bonuses = racialBonuses[selectedRace] || {};
        
        abilityScores.forEach(ability => {
            const abilityElement = document.querySelector(`[data-ability="${ability.toLowerCase()}"]`);
            if (abilityElement) {
                const hasBonus = bonuses[ability.toLowerCase()];
                abilityElement.classList.toggle('racial-bonus', hasBonus);
            }
        });

        updateAbilityScores();
    });

    // Skills
    function createSkillElements() {
        skills.forEach(skill => {
            const skillItem = document.createElement('div');
            skillItem.classList.add('skill-item');
            skillItem.innerHTML = `
                <label>
                    <input type="checkbox" name="skills" value="${skill}">
                    ${skill}
                </label>
            `;
            skillList.appendChild(skillItem);
        });
    }

    // Random Name Generator
    const names = ['Aragorn', 'Legolas', 'Gimli', 'Gandalf', 'Frodo', 'Samwise', 'Bilbo', 'Elrond', 'Galadriel', 'Thorin'];
    randomNameButton.addEventListener('click', () => {
        document.getElementById('name').value = names[Math.floor(Math.random() * names.length)];
    });

    // Character Save Functionality
    function saveJSONCharacter(e) {
        e.preventDefault();
        const formData = new FormData(characterForm);
        const character = Object.fromEntries(formData.entries());
        
        // Get ability scores with racial bonuses
        abilityScores.forEach(ability => {
            const abilityElement = document.querySelector(`[data-ability="${ability.toLowerCase()}"]`);
            if (abilityElement) {
                const baseScore = parseInt(abilityElement.dataset.value) || 0;
                const racialBonus = getRacialBonus(ability.toLowerCase());
                character[ability.toLowerCase()] = baseScore + racialBonus;
            }
        });

        // Get selected skills
        character.skills = formData.getAll('skills');

        // Convert to JSON and save
        const blob = new Blob([JSON.stringify(character, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${character.name}_character.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    // Prevent form submission
    characterForm.addEventListener('submit', (e) => {
        e.preventDefault();
    });

    // Add event listener to the save button
    if (saveCharacterButton) {
        saveCharacterButton.addEventListener('click', saveJSONCharacter);
    }

    // Initialization
    function init() {
        console.log('Initializing application');
        createAbilityScoreElements();
        createSkillElements();
        setupNavigation();
        showCard(-1); // Start by showing the start menu
    }

    init();
});